package com.mitocode.lambda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
